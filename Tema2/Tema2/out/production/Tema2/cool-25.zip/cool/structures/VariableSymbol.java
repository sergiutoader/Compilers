package cool.structures;

public class VariableSymbol extends IdSymbol {

    private String typeName;

    public VariableSymbol(String name, String typeName) {
        super(name);
        this.typeName = typeName;
    }

    public String getTypeName() {
        return typeName;
    }
}
