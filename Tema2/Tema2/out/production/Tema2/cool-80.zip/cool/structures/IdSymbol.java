package cool.structures;

public class IdSymbol extends Symbol {
    public IdSymbol(String name) {
        super(name);
    }
};