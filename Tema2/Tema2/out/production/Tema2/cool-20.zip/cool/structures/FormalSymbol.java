package cool.structures;

public class FormalSymbol extends Symbol {

    private String typeName;

    public FormalSymbol(String name, String typeName) {
        super(name);
        this.typeName = typeName;
    }

    public String getTypeName() {
        return typeName;
    }
}
