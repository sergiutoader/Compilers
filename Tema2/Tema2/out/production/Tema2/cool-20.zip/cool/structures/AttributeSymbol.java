package cool.structures;

public class AttributeSymbol extends IdSymbol {

    public AttributeSymbol(String name) {
        super(name);
    }
}
