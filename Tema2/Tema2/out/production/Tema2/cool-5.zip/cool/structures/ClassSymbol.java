package cool.structures;

import org.antlr.v4.runtime.Token;

import java.util.LinkedHashMap;
import java.util.Map;

public class ClassSymbol extends IdSymbol implements Scope {

    private String parentName;
    private Token nameToken;

    public ClassSymbol(String name, String parentName, Scope parent, Token nameToken) {
        super(name);
        this.parent = parent;
        this.parentName = parentName;
        this.nameToken = nameToken;
    }

    protected Map<String, Symbol> symbols = new LinkedHashMap<>();

    protected Scope parent;

    @Override
    public boolean add(Symbol sym) {
        // Ne asigurăm că simbolul nu există deja în domeniul de vizibilitate
        // curent.
        if (symbols.containsKey(sym.getName()))
            return false;

        symbols.put(sym.getName(), sym);

        return true;
    }

    @Override
    public Symbol lookup(String s) {
        return symbols.get(s);
    }

    @Override
    public Scope getParent() {
        return parent;
    }

    public void setParent(ClassSymbol parent) {
        this.parent = parent;
    }

    public String getParentName() {
        return parentName;
    }

    public Token getNameToken() {
        return nameToken;
    }
}
