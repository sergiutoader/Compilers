package cool.structures;

public class TypeSymbol extends Symbol {

    public static final TypeSymbol INT = new TypeSymbol("Int");

    public TypeSymbol(String name) {
        super(name);
    }

}
