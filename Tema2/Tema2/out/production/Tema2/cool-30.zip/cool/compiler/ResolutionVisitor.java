package cool.compiler;

import cool.structures.*;

import java.text.Normalizer;

import static cool.compiler.ClassDefinitionPassVisitor.*;

public class ResolutionVisitor implements ASTVisitor<TypeSymbol> {
    @Override
    public TypeSymbol visit(Prog prog) {
        for(Class c : prog.classes) {
            c.accept(this);
        }

        return null;
    }

    @Override
    public TypeSymbol visit(Class c) {
        var initialScope = (ClassSymbol) c.classType.getScope();
        var aux = currentScope;
        currentScope = initialScope;
        for(Feature f : c.features) {
            f.accept(this);
        }
        currentScope = aux;
        return null;
    }

    @Override
    public TypeSymbol visit(Method method) {
        var methodName = method.name.ctx.start.getText();
        var mainClass = (ClassSymbol) method.getScope();
        var mainMethod = (MethodSymbol)mainClass.lookup(methodName, true);
        if (mainMethod == null) {
            return null;
        }

        var parentClass = mainClass.getParent();

        while(parentClass instanceof ClassSymbol) {

            var parentMethod = (MethodSymbol) ((ClassSymbol) parentClass).lookup(methodName, true);
            // check if it contains method methodName
            // extract the formal parameters and check how many of them are there
            if (parentMethod != null) {
                var parentFormals = parentMethod.getFormals();
                var mainFormals = mainMethod.getFormals();
                if (parentFormals.size() != mainFormals.size()) {
                    SymbolTable.error(method.ctx, method.name.ctx.start, "Class " + mainClass
                            + " overrides method " + mainMethod
                            + " with different number of formal parameters");
                 } else {
                    for(int i = 0; i < mainFormals.size(); i++) {
                        var formal = mainFormals.get(i);
                        var formalName = formal.getName();
                        var mainType = mainFormals.get(i).getTypeSymbol().getName();
                        var parentType = parentFormals.get(i).getTypeSymbol().getName();
                        if (!mainType.equals(parentType)) {
                            SymbolTable.error(method.ctx, method.formals.get(i).type.name, "Class " + mainClass
                                    + " overrides method " + mainMethod
                                    + " but changes type of formal parameter "
                                    + formalName + " from " + parentType + " to " + mainType);
                        }
                    }
                }
                var mainType = mainMethod.getTypeSymbol().getName();
                var parentType = parentMethod.getTypeSymbol().getName();
                if (!mainType.equals(parentType)) {
                    SymbolTable.error(method.ctx, method.type.name, "Class " + mainClass
                            + " overrides method " + mainMethod
                            + " but changes return type from " + parentType + " to " + mainType);
                }
            }

            parentClass = parentClass.getParent();
        }

        for (Formal f : method.formals) {
            f.accept(this);
        }
        method.body.accept(this);

        var scope = method.body.getScope();
        if (scope == null)
            return null;

        return ((MethodSymbol)scope).getTypeSymbol();
    }

    @Override
    public TypeSymbol visit(Formal formal) {
        var nameToken = formal.id.ctx.start;
        var formalId = nameToken.getText();
        var typeToken = formal.type.name;
        var formalType = typeToken.getText();

        var method = (MethodSymbol) formal.id.getScope();
        var mainClass = (ClassSymbol) method.getParent();

        var parentClass = (ClassSymbol) mainClass.getParent();
        if (parentClass == null) {
            return null;
        }


        return null;
    }

    @Override
    public TypeSymbol visit(Attribute attribute) {
        Scope currScope = currentScope;
        String attributeName = attribute.name.ctx.start.getText();
        while (true) {
            var parentScope = currScope.getParent();

            if(!(parentScope instanceof ClassSymbol)) {
                break;
            }

            var classScope = ((ClassSymbol)parentScope);
            if (classScope.lookup(attributeName, false) != null) {
                SymbolTable.error(attribute.ctx, attribute.name.ctx.start, "Class " + currentScope
                        + " redefines inherited attribute " + attributeName);
                return null;
            }

            currScope = parentScope;
        }

        currScope = currentScope;
        var attributeSymbol = ((ClassSymbol)currScope).lookup(attributeName, false);

        if (attributeSymbol == null) {
            return null;
        }
        var expectedType = ((AttributeSymbol)attributeSymbol).getTypeSymbol();

        if (attribute.defaultVal != null) {
            var defaultValType = attribute.defaultVal.accept(this);
            if (defaultValType == null) {
                SymbolTable.error(attribute.ctx, attribute.defaultVal.ctx.start, "Undefined identifier " + attribute.defaultVal.ctx.getText());
            }
        }

        return expectedType;
    }

    @Override
    public TypeSymbol visit(Let let) {

        for (Local l : let.locals) {
            l.accept(this);
        }


        return null;
    }

    @Override
    public TypeSymbol visit(Type typeId) {
        return null;
    }

    @Override
    public TypeSymbol visit(ObjectId objectId) {
        return null;
    }

    @Override
    public TypeSymbol visit(Int i) {
        return TypeSymbol.INT;
    }

    @Override
    public TypeSymbol visit(Stringg string) {
        return null;
    }

    @Override
    public TypeSymbol visit(True t) {
        return null;
    }

    @Override
    public TypeSymbol visit(False f) {
        return null;
    }

    @Override
    public TypeSymbol visit(Id id) {
        var idName = id.value.ctx.start.getText();
        var currScope = currentScope;

        while (currScope != null) {
            if (currScope instanceof ClassSymbol) {
                var classScope = (ClassSymbol)currScope;
                var symbol = classScope.lookup(idName, false);
                if (symbol instanceof AttributeSymbol) {
                    var attributeSymbol = (AttributeSymbol)symbol;
                    return attributeSymbol.getTypeSymbol();
                }
            } else if (currScope instanceof LetSymbol) {
                var letScope = (LetSymbol)currScope;
                var symbol = letScope.lookup(idName);
                if (symbol instanceof VariableSymbol) {
                    var variableSymbol = (VariableSymbol)symbol;
                    return variableSymbol.getTypeSymbol();
                }
            } else if (currScope instanceof MethodSymbol) {
                var methodScope = (MethodSymbol)currScope;
                var symbol = methodScope.lookup(idName);
                if (symbol instanceof FormalSymbol) {
                    var formalSymbol = (FormalSymbol)symbol;
                    return formalSymbol.getTypeSymbol();
                }
            }

            currScope = currScope.getParent();
        }

        return null;
    }

    @Override
    public TypeSymbol visit(Paren paren) {
        return null;
    }

    @Override
    public TypeSymbol visit(MultDiv multDiv) {
        return null;
    }

    @Override
    public TypeSymbol visit(PlusMinus plusMinus) {
        return null;
    }

    @Override
    public TypeSymbol visit(Negative negative) {
        return null;
    }

    @Override
    public TypeSymbol visit(Relational relational) {
        return null;
    }

    @Override
    public TypeSymbol visit(Not not) {
        return null;
    }

    @Override
    public TypeSymbol visit(Assign assign) {
        return null;
    }

    @Override
    public TypeSymbol visit(IsVoid isVoid) {
        return null;
    }

    @Override
    public TypeSymbol visit(New n) {
        return null;
    }

    @Override
    public TypeSymbol visit(ImplicitDispatch implicitDispatch) {
        return null;
    }

    @Override
    public TypeSymbol visit(ExplicitDispatch explicitDispatch) {
        return null;
    }

    @Override
    public TypeSymbol visit(If iff) {
        return null;
    }

    @Override
    public TypeSymbol visit(While whilee) {
        return null;
    }

    @Override
    public TypeSymbol visit(Local local) {
        if (local.expression == null) {
            return null;
        }
        var currScope = currentScope;
        currentScope = local.expression.getScope();

        TypeSymbol result = local.expression.accept(this);
        if (result == null) {
            SymbolTable.error(local.ctx, local.expression.ctx.start, "Undefined identifier " + local.expression.ctx.getText());
        }

        currentScope = currScope;
        return result;
    }

    @Override
    public TypeSymbol visit(Case casee) {
        return null;
    }

    @Override
    public TypeSymbol visit(CaseBranch caseBranch) {
        return null;
    }

    @Override
    public TypeSymbol visit(Block block) {
        return null;
    }
}
