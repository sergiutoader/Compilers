package cool.compiler;

import cool.structures.*;

// Checks for loops inside class hierarchy
public class ClassHierarchyValidationVisitor implements ASTVisitor<Void> {

    @Override
    public Void visit(Prog prog) {
        for (Class c : prog.classes) {
            c.accept(this);
        }
        return null;
    }

    @Override
    public Void visit(Class c) {
        ClassSymbol initialScope = (ClassSymbol) c.classType.getScope();
        if (initialScope == null) {
            return null;
        }

        Scope currentScope = c.classType.getScope();
        while (currentScope instanceof ClassSymbol) {
            var parentScope = currentScope.getParent();

            if(!(parentScope instanceof ClassSymbol)) {
                break;
            }

            var classScope = ((ClassSymbol)parentScope);
            if (classScope.getName().equals(initialScope.getName())) {
                SymbolTable.error(c.ctx, c.classType.name, "Inheritance cycle for class " + initialScope.getName());
                c.setInheritanceCycle(true);
                break;
            }

            currentScope = parentScope;
        }

        if (!c.hasInheritanceCycle()) {
            var aux = ClassDefinitionPassVisitor.currentScope;
            ClassDefinitionPassVisitor.currentScope = initialScope;
            for (Feature f : c.features) {
                f.accept(this);
            }
            ClassDefinitionPassVisitor.currentScope = aux;
        }
        return null;
    }

    @Override
    public Void visit(Method method) {
        return null;
    }

    @Override
    public Void visit(Attribute attribute) {
        var token = attribute.name.ctx.start;
        var attributeName = token.getText();
        var currentScope = ClassDefinitionPassVisitor.currentScope;

        if (attributeName.equals("self")) {
            SymbolTable.error(attribute.ctx, token, "Class "
                    + ClassDefinitionPassVisitor.currentScope
                    + " has attribute with illegal name "
                    + attributeName);
            return null;
        }

        if (currentScope.lookup(attributeName) != null) {
            SymbolTable.error(attribute.ctx, token, "Class "
                    + ClassDefinitionPassVisitor.currentScope
                    + " redefines attribute "
                    + attributeName);
            return null;
        }

        String typeName = attribute.type.name.getText();
        if (!ClassDefinitionPassVisitor.predefinedTypes.contains(typeName)
                && ClassDefinitionPassVisitor.globalScope.lookup(typeName) == null) {
            SymbolTable.error(attribute.ctx, attribute.type.name, "Class "
                    + ClassDefinitionPassVisitor.currentScope
                    + " has attribute "
                    + attributeName + " with undefined type " + typeName);
        }

        var symbol = new IdSymbol(attributeName);
        currentScope.add(symbol);

        return null;
    }

    @Override
    public Void visit(Type typeId) {
        return null;
    }

    @Override
    public Void visit(ObjectId objectId) {
        return null;
    }

    @Override
    public Void visit(Formal formal) {
        return null;
    }

    @Override
    public Void visit(Int i) {
        return null;
    }

    @Override
    public Void visit(Stringg string) {
        return null;
    }

    @Override
    public Void visit(True t) {
        return null;
    }

    @Override
    public Void visit(False f) {
        return null;
    }

    @Override
    public Void visit(Id id) {
        return null;
    }

    @Override
    public Void visit(Paren paren) {
        return null;
    }

    @Override
    public Void visit(MultDiv multDiv) {
        return null;
    }

    @Override
    public Void visit(PlusMinus plusMinus) {
        return null;
    }

    @Override
    public Void visit(Negative negative) {
        return null;
    }

    @Override
    public Void visit(Relational relational) {
        return null;
    }

    @Override
    public Void visit(Not not) {
        return null;
    }

    @Override
    public Void visit(Assign assign) {
        return null;
    }

    @Override
    public Void visit(IsVoid isVoid) {
        return null;
    }

    @Override
    public Void visit(New n) {
        return null;
    }

    @Override
    public Void visit(ImplicitDispatch implicitDispatch) {
        return null;
    }

    @Override
    public Void visit(ExplicitDispatch explicitDispatch) {
        return null;
    }

    @Override
    public Void visit(If iff) {
        return null;
    }

    @Override
    public Void visit(While whilee) {
        return null;
    }

    @Override
    public Void visit(Local local) {
        return null;
    }

    @Override
    public Void visit(Let let) {
        return null;
    }

    @Override
    public Void visit(Case casee) {
        return null;
    }

    @Override
    public Void visit(CaseBranch caseBranch) {
        return null;
    }

    @Override
    public Void visit(Block block) {
        return null;
    }
}
