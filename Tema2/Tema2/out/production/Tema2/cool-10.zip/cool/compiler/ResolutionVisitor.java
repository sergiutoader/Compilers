package cool.compiler;

import cool.structures.ClassSymbol;
import cool.structures.Scope;
import cool.structures.SymbolTable;

import static cool.compiler.ClassDefinitionPassVisitor.currentScope;

public class ResolutionVisitor implements ASTVisitor<Void> {
    @Override
    public Void visit(Prog prog) {
        for(Class c : prog.classes) {
            c.accept(this);
        }

        return null;
    }

    @Override
    public Void visit(Class c) {
        var initialScope = (ClassSymbol) c.classType.getScope();
        var aux = currentScope;
        currentScope = initialScope;
        for(Feature f : c.features) {
            f.accept(this);
        }
        currentScope = aux;
        return null;
    }

    @Override
    public Void visit(Method method) {
        return null;
    }

    @Override
    public Void visit(Attribute attribute) {
        Scope currScope = currentScope;
        String attributeName = attribute.name.ctx.start.getText();
        while (true) {
            var parentScope = currScope.getParent();

            if(!(parentScope instanceof ClassSymbol)) {
                break;
            }

            var classScope = ((ClassSymbol)parentScope);
            if (classScope.lookup(attributeName) != null) {
                SymbolTable.error(attribute.ctx, attribute.name.ctx.start, "Class " + currentScope
                        + " redefines inherited attribute " + attributeName);
                return null;
            }

            currScope = parentScope;
        }
        return null;
    }

    @Override
    public Void visit(Type typeId) {
        return null;
    }

    @Override
    public Void visit(ObjectId objectId) {
        return null;
    }

    @Override
    public Void visit(Formal formal) {
        return null;
    }

    @Override
    public Void visit(Int i) {
        return null;
    }

    @Override
    public Void visit(Stringg string) {
        return null;
    }

    @Override
    public Void visit(True t) {
        return null;
    }

    @Override
    public Void visit(False f) {
        return null;
    }

    @Override
    public Void visit(Id id) {
        return null;
    }

    @Override
    public Void visit(Paren paren) {
        return null;
    }

    @Override
    public Void visit(MultDiv multDiv) {
        return null;
    }

    @Override
    public Void visit(PlusMinus plusMinus) {
        return null;
    }

    @Override
    public Void visit(Negative negative) {
        return null;
    }

    @Override
    public Void visit(Relational relational) {
        return null;
    }

    @Override
    public Void visit(Not not) {
        return null;
    }

    @Override
    public Void visit(Assign assign) {
        return null;
    }

    @Override
    public Void visit(IsVoid isVoid) {
        return null;
    }

    @Override
    public Void visit(New n) {
        return null;
    }

    @Override
    public Void visit(ImplicitDispatch implicitDispatch) {
        return null;
    }

    @Override
    public Void visit(ExplicitDispatch explicitDispatch) {
        return null;
    }

    @Override
    public Void visit(If iff) {
        return null;
    }

    @Override
    public Void visit(While whilee) {
        return null;
    }

    @Override
    public Void visit(Local local) {
        return null;
    }

    @Override
    public Void visit(Let let) {
        return null;
    }

    @Override
    public Void visit(Case casee) {
        return null;
    }

    @Override
    public Void visit(CaseBranch caseBranch) {
        return null;
    }

    @Override
    public Void visit(Block block) {
        return null;
    }
}
