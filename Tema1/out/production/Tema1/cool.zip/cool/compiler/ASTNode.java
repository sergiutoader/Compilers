package cool.compiler;
import org.antlr.v4.runtime.Token;

import java.util.ArrayList;

// Rădăcina ierarhiei de clase reprezentând nodurile arborelui de sintaxă
// abstractă (AST). Singura metodă permite primirea unui visitor.
public abstract class ASTNode {
    Token token;
    ASTNode(Token token) {
        this.token = token;
    }

    public <T> T accept(ASTVisitor<T> visitor) {
        return null;
    }
}

class Type extends ASTNode {
    Type(Token token) {
        super(token);
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class ObjectId extends ASTNode {
    ObjectId(Token token) {
        super(token);
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Expr extends ASTNode {

    Expr(Token token) {
        super(token);
    }
}

class New extends Expr {
    ObjectId id;

    New(Token token, ObjectId id) {
        super(token);
        this.id = id;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Local extends ASTNode {
    ObjectId id;
    Type type;
    Expr expression;

    Local(Token token, ObjectId id, Type type, Expr expression) {
        super(token);
        this.id = id;
        this.type = type;
        this.expression = expression;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class CaseBranch extends ASTNode {
    ObjectId id;
    Type type;
    Expr e;

    CaseBranch(Token token, ObjectId id, Type type, Expr e) {
        super(token);
        this.id = id;
        this.type = type;
        this.e = e;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Case extends Expr {
    Expr ref_expr;
    ArrayList<CaseBranch> case_branches;

    Case(Token token, Expr ref_expr, ArrayList<CaseBranch> case_branches) {
        super(token);
        this.ref_expr = ref_expr;
        this.case_branches = case_branches;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Let extends Expr {
    ArrayList<Local> locals;
    Expr body;

    Let(Token token, ArrayList<Local> locals, Expr body) {
        super(token);
        this.locals = locals;
        this.body = body;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class While extends Expr {
    Expr cond;
    Expr body;

    While(Token token, Expr cond, Expr body) {
        super(token);
        this.cond = cond;
        this.body = body;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class If extends Expr {
    Expr cond;
    Expr thenBranch;
    Expr elseBranch;

    If(Token token, Expr cond, Expr thenBranch, Expr elseBranch) {
        super(token);
        this.cond = cond;
        this.thenBranch = thenBranch;
        this.elseBranch = elseBranch;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class ImplicitDispatch extends Expr {
    ObjectId funcName;
    ArrayList<Expr> formalParams;

    ImplicitDispatch(Token token, ObjectId funcName, ArrayList<Expr> formalParams) {
        super(token);
        this.funcName = funcName;
        this.formalParams = formalParams;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class ExplicitDispatch extends Expr {
    Expr object;
    Type type;
    ObjectId funcName;
    ArrayList<Expr> formalParams;

    ExplicitDispatch(Token token, Expr object, Type type, ObjectId funcName, ArrayList<Expr> formalParams) {
        super(token);
        this.object = object;
        this.type = type;
        this.funcName = funcName;
        this.formalParams = formalParams;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class IsVoid extends Expr {
    Expr e;

    IsVoid(Token token, Expr e) {
        super(token);
        this.e = e;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Assign extends Expr {
    Expr e;
    ObjectId id;

    Assign(Token token, ObjectId id, Expr e) {
        super(token);
        this.id = id;
        this.e = e;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Not extends Expr {
    Expr e;

    Not(Token token, Expr e) {
        super(token);
        this.e = e;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Relational extends Expr {
    Expr left;
    Expr right;
    Token op;

    Relational(Token token, Expr left, Token op, Expr right) {
        super(token);
        this.left = left;
        this.op = op;
        this.right = right;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Negative extends Expr {
    Expr e;

    Negative(Token token, Expr e) {
        super(token);
        this.e = e;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class MultDiv extends Expr {
    Expr left;
    Expr right;
    Token op;

    MultDiv(Token token, Expr left, Token op, Expr right) {
        super(token);
        this.left = left;
        this.op = op;
        this.right = right;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class PlusMinus extends Expr {
    Expr left;
    Expr right;
    Token op;

    PlusMinus(Token token, Expr left, Token op, Expr right) {
        super(token);
        this.left = left;
        this.op = op;
        this.right = right;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Paren extends Expr {
    Expr e;

    Paren(Token token, Expr e) {
        super(token);
        this.e = e;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Id extends Expr {
    ObjectId value;

    Id(Token token) {
        super(token);
        this.value = new ObjectId(token);
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Stringg extends Expr {
    Token value;

    Stringg(Token token) {
        super(token);
        this.value = token;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class True extends Expr {
    Token value;

    True(Token token) {
        super(token);
        this.value = token;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class False extends Expr {
    Token value;

    False(Token token) {
        super(token);
        this.value = token;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Int extends Expr {
    Token value;

    Int(Token token) {
        super(token);
        this.value = token;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Feature extends ASTNode {

    Feature(Token token) {
        super(token);
    }
}

class Formal extends ASTNode {

    ObjectId id;
    Type type;

    Formal(Token token, ObjectId id, Type type) {
        super(token);
        this.id = id;
        this.type = type;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Method extends Feature {
    ObjectId name;
    ArrayList<Formal> formals;
    Type type;
    Expr body;

    Method(Token token, ObjectId name, ArrayList<Formal> formals, Type type, Expr body) {
        super(token);
        this.name = name;
        this.formals = formals;
        this.type = type;
        this.body = body;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

class Attribute extends Feature {
    ObjectId name;
    Type type;
    Expr defaultVal;

    Attribute(Token token, ObjectId name, Type type, Expr defaultVal) {
        super(token);
        this.name = name;
        this.type = type;
        this.defaultVal = defaultVal;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}


class Class extends ASTNode {
    Type name;
    Type parentName;
    ArrayList<Feature> features;

    Class(Token token, Type name, Type parentName, ArrayList<Feature> features) {
        super(token);
        this.name = name;
        this.parentName = parentName;
        this.features = features;
    }

    @Override
    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}

// Program
class Prog extends ASTNode {
    ArrayList<Class> classes;

    Prog(Token token, ArrayList<Class> classes) {
        super(token);
        this.classes = classes;
    }

    public <T> T accept(ASTVisitor<T> visitor) {
        return visitor.visit(this);
    }
}